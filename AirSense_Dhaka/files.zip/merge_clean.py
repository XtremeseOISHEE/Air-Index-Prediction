"""
AirSense Dhaka - Data Merge & Cleaning Script
-----------------------------------------------
Merges 7 yearly WAQI PM2.5 export files (2016-2022) into one clean,
continuous hourly time-series dataset ready for ML modeling.

Steps:
1. Load all 7 CSVs, standardize columns
2. Concatenate + sort chronologically
3. Replace -999 (sentinel for missing) with NaN
4. Interpolate short gaps (linear) - justified since PM2.5 changes gradually hour-to-hour
5. Flag rows that were interpolated vs originally valid (for transparency in report)
6. Feature engineering: month, day_of_week, season, hour, is_weekend
7. Save final master CSV + a data-quality summary
"""

import pandas as pd
import numpy as np
import glob
import os

INPUT_DIR = "/mnt/user-data/uploads"
OUTPUT_DIR = "/mnt/user-data/outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

files = sorted(glob.glob(os.path.join(INPUT_DIR, "Dhaka_PM2_5_*.csv")))
print(f"Found {len(files)} files:")
for f in files:
    print(" -", os.path.basename(f))

# ---------- 1 & 2: Load and merge ----------
dfs = []
for f in files:
    df = pd.read_csv(f)
    df.columns = [c.strip() for c in df.columns]  # standardize column names
    dfs.append(df)

merged = pd.concat(dfs, ignore_index=True)

# Parse datetime (format: DD/MM/YYYY HH:MM)
merged["datetime"] = pd.to_datetime(merged["Date (LT)"], format="%d/%m/%Y %H:%M", errors="coerce")

# Drop any rows where datetime failed to parse (corrupted rows, if any)
bad_dates = merged["datetime"].isna().sum()
merged = merged.dropna(subset=["datetime"])

# Sort chronologically, drop exact duplicate timestamps (keep first)
merged = merged.sort_values("datetime").drop_duplicates(subset="datetime", keep="first")
merged = merged.reset_index(drop=True)

print(f"\nTotal merged rows: {len(merged)}")
print(f"Rows with unparseable dates dropped: {bad_dates}")
print(f"Date range: {merged['datetime'].min()} to {merged['datetime'].max()}")

# ---------- 3: Replace -999 sentinel with NaN ----------
for col in ["NowCast Conc.", "Raw Conc.", "AQI"]:
    merged[col] = pd.to_numeric(merged[col], errors="coerce")
    merged.loc[merged[col] == -999, col] = np.nan

n_missing_before = merged["Raw Conc."].isna().sum()
pct_missing = 100 * n_missing_before / len(merged)
print(f"\nMissing (Raw Conc.) before interpolation: {n_missing_before} ({pct_missing:.1f}%)")

# ---------- 4: Reindex to continuous hourly range (fills any skipped hours too) ----------
full_range = pd.date_range(start=merged["datetime"].min(), end=merged["datetime"].max(), freq="h")
merged = merged.set_index("datetime").reindex(full_range)
merged.index.name = "datetime"

n_missing_after_reindex = merged["Raw Conc."].isna().sum()
print(f"Missing after reindexing to full continuous hourly range: {n_missing_after_reindex} "
      f"({100*n_missing_after_reindex/len(merged):.1f}%)")

# Track which rows were originally missing/interpolated (for transparency)
merged["was_missing"] = merged["Raw Conc."].isna()

# Interpolate short gaps (limit=24 -> won't bridge gaps longer than 24 hours / 1 day)
for col in ["NowCast Conc.", "Raw Conc.", "AQI"]:
    merged[col] = merged[col].interpolate(method="linear", limit=24, limit_direction="both")

n_still_missing = merged["Raw Conc."].isna().sum()
print(f"Still missing after interpolation (gaps >24h, left as NaN): {n_still_missing} "
      f"({100*n_still_missing/len(merged):.1f}%)")

# ---------- 5: Feature engineering ----------
merged = merged.reset_index()
merged["year"] = merged["datetime"].dt.year
merged["month"] = merged["datetime"].dt.month
merged["day_of_week"] = merged["datetime"].dt.dayofweek  # 0=Monday
merged["hour"] = merged["datetime"].dt.hour
merged["is_weekend"] = merged["day_of_week"].isin([4, 5]).astype(int)  # Fri/Sat weekend in Bangladesh

def get_season(month):
    if month in [12, 1, 2]:
        return "Winter"      # worst AQI - brick kilns, no rain to wash out particles
    elif month in [3, 4, 5]:
        return "Pre-Monsoon"
    elif month in [6, 7, 8, 9]:
        return "Monsoon"     # best AQI - rain washes out particulates
    else:
        return "Post-Monsoon"

merged["season"] = merged["month"].apply(get_season)

# Rebuild AQI category from cleaned AQI values (since original had "N/A" for missing rows)
def aqi_category(aqi):
    if pd.isna(aqi):
        return np.nan
    if aqi <= 50: return "Good"
    if aqi <= 100: return "Moderate"
    if aqi <= 150: return "Unhealthy for Sensitive Groups"
    if aqi <= 200: return "Unhealthy"
    if aqi <= 300: return "Very Unhealthy"
    return "Hazardous"

merged["aqi_category"] = merged["AQI"].apply(aqi_category)

# Lag features (yesterday same hour, previous hour) - standard in AQI forecasting research
merged["pm25_lag_1h"] = merged["Raw Conc."].shift(1)
merged["pm25_lag_24h"] = merged["Raw Conc."].shift(24)

# ---------- 6: Final column selection & save ----------
final_cols = [
    "datetime", "year", "month", "day_of_week", "hour", "is_weekend", "season",
    "Raw Conc.", "NowCast Conc.", "AQI", "aqi_category",
    "pm25_lag_1h", "pm25_lag_24h", "was_missing"
]
final = merged[final_cols].rename(columns={
    "Raw Conc.": "pm25_raw",
    "NowCast Conc.": "pm25_nowcast",
    "AQI": "aqi"
})

out_path = os.path.join(OUTPUT_DIR, "dhaka_aqi_master_2016_2022.csv")
final.to_csv(out_path, index=False)
print(f"\nSaved cleaned master file to: {out_path}")
print(f"Final shape: {final.shape}")

# ---------- 7: Data quality summary ----------
summary_lines = []
summary_lines.append("AirSense Dhaka - Data Quality Summary\n")
summary_lines.append("="*50)
summary_lines.append(f"Source files merged: {len(files)} (years 2016-2022)")
summary_lines.append(f"Final date range: {final['datetime'].min()} to {final['datetime'].max()}")
summary_lines.append(f"Total hourly rows (continuous): {len(final)}")
summary_lines.append(f"Rows originally missing (-999): {n_missing_after_reindex} ({100*n_missing_after_reindex/len(final):.1f}%)")
summary_lines.append(f"Rows recovered via linear interpolation (gaps <=24h): {n_missing_after_reindex - n_still_missing}")
summary_lines.append(f"Rows still missing after interpolation (gaps >24h, left as NaN): {n_still_missing} ({100*n_still_missing/len(final):.1f}%)")
summary_lines.append("\nRows per year:")
summary_lines.append(str(final.groupby("year").size()))
summary_lines.append("\nAverage PM2.5 by season:")
summary_lines.append(str(final.groupby("season")["pm25_raw"].mean().sort_values(ascending=False)))

summary_text = "\n".join(summary_lines)
print("\n" + summary_text)

with open(os.path.join(OUTPUT_DIR, "data_quality_summary.txt"), "w") as f:
    f.write(summary_text)
